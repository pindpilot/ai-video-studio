# Adding a provider

This is the implementation contract for the next milestone, not a working plug-in loader yet.

1. Verify the exact operation in official API documentation and add its source/date,
   endpoint/auth, request limits, language/ratio/duration/resolution and usage/license
   conditions to PROVIDER_MATRIX.md. Unverified = not eligible.
2. Add one adapter file conforming to the relevant normalized capability protocol.
3. Add one manifest entry. Do not change UI or queue code for a new model.
4. Add recorded, sanitized contract fixtures. Never include keys or personal media.
5. Classify quota/rate/unavailable/auth/transient/input/policy errors. Follow Retry-After.
6. Require configuration in Keychain, explicit enablement and capability eligibility.
   No hidden paid fallback. If the quota is shared, record the shared account bucket.
7. Prove mock fallback and all-fail tests, then test live availability only through
   the user-controlled Model Manager. Documentation verification is not a connection test.
8. Never silently change languages, voice, ratio, licensing or moderation behavior.
